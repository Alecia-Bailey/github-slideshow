<?php
$connect = new MongoClient("mongodb+srv://customer:customer123@cluster0.yfnomas.mongodb.net/test");
$db = $connect ->hw4;
//$collection = $db->hw4;
$cursor=$db->find(); //cursor is the variable
foreach($cursor as $result){
    print_r($result);
}

//$Product = $db->hw4;

?>


