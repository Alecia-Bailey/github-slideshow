<?php

require "mongo.php";
$smalldata = $connect->hw4->Product;
$middata = $connect->hw4->Product;
$largedata = $connect->hw4->Product;

$dataset = [
    '_id' => 1,
    'product_name' => 'Ramen',
    'product_description' => 'Cup Noodles',
    'product_unit' => 'Kilograms',
    'product_price' => 0.54,
    'product_quantity' => 22,
    'product_status' => 2,
];

$d500 = [];
for ($i = 0; $i < 500; $i++) {
    $d500[] = $dataset;
}

$d5000 = [];
for ($i = 0; $i < 5000; $i++) {
    $d5000[] = $dataset;
}

$d100k = [];
for ($i = 0; $i < 100000; $i++) {
    $d100k[] = $dataset;
}

// 500 Records
$time_start = microtime(true);
$insertManyResult = $smalldata->insertMany($d500);
$time_end = microtime(true);
echo '<b>500 Records Create Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $smalldata->updateOne([], ['$set' => ['product_name'  => 'Trix']]);
$time_end = microtime(true);
echo '<b>500 Records Update Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $smalldata->find(['product_name'  => 'Trix']);
$time_end = microtime(true);
echo '<b>500 Records Select Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $smalldata->deleteMany([]);
$time_end = microtime(true);
echo '<b>500 Records Delete Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

// 5000 records
$time_start = microtime(true);
$insertManyResult = $middata->insertMany($d5000);
$time_end = microtime(true);
echo '<b>5000 Records Create Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $middata->updateOne([], ['$set' => ['product_name'  => 'Trix']]);
$time_end = microtime(true);
echo '<b>5000 Records Update Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $middata->find(['product_name'  => 'Trix']);
$time_end = microtime(true);
echo '<b>5000 Records Select Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $middata->deleteMany([]);
$time_end = microtime(true);
echo '<b>5000 Records Delete Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

// 100,000 records
$time_start = microtime(true);
$insertManyResult = $largedata->insertMany($d100k);
$time_end = microtime(true);
echo '<b>100k Records Create Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $largedata->updateOne([], ['$set' => ['product_name'  => 'Hersheys']]);
$time_end = microtime(true);
echo '<b>100k Records Update Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $largedata->find(['product_name'  => 'Hersheys']);
$time_end = microtime(true);
echo '<b>100k Records Select Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';

$time_start = microtime(true);
$insertManyResult = $largedata->deleteMany([]);
$time_end = microtime(true);
echo '<b>100k Records Delete Execution Time:</b> ' . ($time_end - $time_start) . ' Seconds <br>';