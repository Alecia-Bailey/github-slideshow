-- phpMyAdmin SQL Dump
-- http://itwsdbas.eastus.cloudapp.azure.com/phpmyadmin/
-- login: username= bailea2 and password= Ale#pp16
--
-- Host: 127.0.0.1
-- Server version: 10.6.7-MariaDB
-- PHP Version: 8.1.2

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bailea2`
--

-- --------------------------------------------------------

--
-- Roles for Customer and Supplier.
-- In the Customer table the username is `customer` and `supplier` in the Supplier table.

GRANT INSERT, UPDATE, DELETE ON Order_Detail TO `customer`;
GRANT SELECT ON Product TO `customer`;

GRANT INSERT, UPDATE, DELETE ON Product TO `supplier`;

-- --------------------------------------------------------

--
-- Table structure for table `Payment`
--

DROP TABLE IF EXISTS `Payment`;

CREATE TABLE IF NOT EXISTS `Payment` (
  `Bill_number` int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `Payment_Type` varchar(40) NOT NULL,
  `Other_details` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `Supplier`
--

DROP TABLE IF EXISTS `Supplier`;

CREATE TABLE IF NOT EXISTS `Supplier` (
  `Supplier_ID` int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `Name` varchar(40) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `Phone` int(10) NOT NULL,
  `Fax` int(10) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Other_details` varchar(40) NOT NULL,
  `Username` varchar(40) NOT NULL,
  `Password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Inserting data for table `Supplier`
--

INSERT INTO `Supplier` (`Name`,  `Address`, `Phone`, `Fax`, `Email`, `Other_details`, `Username`, `Password`) VALUES
('alecia', 'Downtown Troy', 2147483647, 2147483647, 'alecia@gmail.com', 'Cooked food', 'supplier', 'supplier123'),
('Ashley Furniture', 'Liberty Lodge', 2147483646, 2147483646, 'ashley@yahoo.com', 'Main branch', 'supplier', 'supplier123'),
('Bryan Photo Studio', 'Peoples Avenue', 2147483645, 2147483645, 'bryanps@aol.com', 'Main branch', 'supplier', 'supplier123'),
('Best Buy', '4th Street', 2147483644, 2147483644, 'bestbuy@yahoo.com', 'Main branch', 'supplier', 'supplier123'),
('Paul', 'Downtown Troy', 2147483643, 2147483643, 'paul@yahoo.com', 'Downtown branch', 'supplier', 'supplier123'),
('Richard', 'Mountain View', 2147483642, 2147483642, 'richard@yahoo.com', 'Main branch', 'supplier', 'supplier123');

-- --------------------------------------------------------

--
-- Table structure for table `Customer`
--

DROP TABLE IF EXISTS `Customer`;

CREATE TABLE IF NOT EXISTS `Customer` (
  `Customer_ID` int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `First_Name` varchar(40) NOT NULL,
  `Last_Name` varchar(40) NOT NULL,
  `Address` varchar(40) NOT NULL,
  `Phone` int(10) NOT NULL,
  `Email` varchar(40) NOT NULL,
  `Staff_ID` int(10) NOT NULL,
  `Username` varchar(40) NOT NULL,
  `Password` varchar(40) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Inserting data for table `Customer`
--

INSERT INTO `Customer` (`First_Name`, `Last_Name`, `Address`, `Phone`, `Email`, `Staff_ID`, `Username`, `Password`) VALUES
('alecia', 'bailey', 'Congress Street', 5, 'alecia@gmail.com', 1, 'customer', 'customer123'),
('emily', 'shields', 'Congress Street', 518, 'shields@gmail.com', 2, 'customer', 'customer123'),
('mark', 'dixon', 'Peoples Avenue', 522, 'mdixon@gmail.com', 3, 'customer', 'customer123'),
('sharon', 'jones', 'City Station', 532, 'sjones@gmail.com', 4, 'customer', 'customer123'),
('allison', 'hinds', 'College Avenue', 534, 'hinds@gmail.com', 5, 'customer', 'customer123'),
('anna', 'pavlov', 'Washington Street', 656, 'anna@gmail.com', 6, 'customer', 'customer123');

-- --------------------------------------------------------

--
-- Table structure for table `Product`
--

DROP TABLE IF EXISTS `Product`;

CREATE TABLE IF NOT EXISTS `Product` (
  `Product_ID` varchar(40) NOT NULL PRIMARY KEY,
  `Product_Name` varchar(40) NOT NULL,
  `Product_Description` varchar(40) NOT NULL,
  `Product_Unit` varchar(40) NOT NULL,
  `Product_Price` float(8) NOT NULL,
  `Product_Quantity` int(10) NOT NULL,
  `Product_Status` int(10) NOT NULL,
  `Other_details` varchar(40) NOT NULL,
  `Supplier_ID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------
--
-- Inserting data for table `Product`
--

INSERT INTO `Product` (`Product_ID`,`Product_Name`, `Product_Description`, `Product_Unit`, `Product_Price`, `Product_Quantity`, `Product_Status`, `Other_details`, `Supplier_ID`) VALUES
('Prod1', 'Kit Kat', 'Chocolate', 'Grams', '5.9', '100', '1', 'Ready to eat', '1'),
('Prod2', 'Pancake', 'Breakfast item', 'Grams', '20.20', '200', '2', 'Need to be prepared', '1'),
('Prod3', 'Cup Noodles', 'Ramen Noodles Soup', 'Grams', '3.49', '50', '1', 'Pour hot water before eating', '1'),
('Prod4', 'BMW', 'Motor Vehicle', 'Kilograms', '22000.9', '200', '2', 'Ready to drive off the lot', '1'),
('Prod5', 'Rice', 'Long grain white rice', 'Tons', '10.45', '20', '2', 'Need to be cooked before eaten', '1');

--PHP Code
-- $sql = "INSERT INTO `Product` (`Product_ID`, `Product_Name`, `Product_Description`, `Product_Unit`, `Product_Price`, `Product_Quantity`, `Product_Status`, `Other_details`, `Supplier_ID`) VALUES (\'Prod1\', \'Kit Kat\', \'Chocolate\', \'Grams\', \'5.9\', \'100\', \'1\', \'Ready to eat\', \'1\');";


--
-- Table structure for table `Order_Detail`
--

DROP TABLE IF EXISTS `Order_Detail`;

CREATE TABLE IF NOT EXISTS `Order_Detail` (
    `Order_Detail_ID` int(10) NOT NULL AUTO_INCREMENT PRIMARY KEY,
    `Unit_Price` float(8) NOT NULL,
    `Customer_ID` int(10) NOT NULL,
    `Quantity` int(10) NOT NULL,
    `Discount` int(10) NOT NULL,
    `Total` float(8) NOT NULL,
    `Date` date NOT NULL,
    `Product_ID` varchar(40) NOT NULL,
    `Status` varchar(10) NOT NULL,
    `Bill_number` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Foreign Key for table `Customer`
--
ALTER TABLE `Customer`
  ADD FOREIGN KEY (`Staff_ID`) REFERENCES Customer (`Customer_ID`) ;

--
-- Foreign Key for table `Product`
--
ALTER TABLE `Product`
  ADD FOREIGN KEY (`Supplier_ID`) REFERENCES Supplier (`Supplier_ID`);

--
-- Foreign Key for table `Order_Detail`
--
ALTER TABLE `Order_Detail`
  ADD FOREIGN KEY (`Customer_ID`) REFERENCES Customer (`Customer_ID`);

ALTER TABLE `Order_Detail`
    ADD FOREIGN KEY (`Product_ID`) REFERENCES Product (`Product_ID`);

ALTER TABLE `Order_Detail`
    ADD FOREIGN KEY (`Bill_number`) REFERENCES Payment (`Bill_number`);


--
-- Trigger to update Order Status
--
-- CREATE TRIGGER Order_Success
--  AFTER INSERT ON Order_Detail
--  FOR EACH ROW
--  BEGIN
--      IF EXISTS (SELECT Bill_number FROM Order_Detail) THEN
--          INSERT INTO Order_Detail (`Status`)
--          VALUE ('SUCCESS');
--      ELSE
--          INSERT INTO Order_Detail (`Status`)
--         VALUE ('FAIL');
--  END;

CREATE TRIGGER Order_Status
AFTER INSERT ON Payment
FOR EACH ROW
BEGIN
    IF Bill_number = NEW.Bill_number THEN
        UPDATE `Order_Detail` SET `Status` = 'SUCCESS';
    ELSE
        UPDATE `Order_Detail` SET `Status` = 'FAIL';
END;


--
-- Store Procedures for Successful and Failed Orders
--

CREATE PROCEDURE Successful_Order (IN `Old_OID` INT(10), IN `Quantity` INT, IN `Prod_ID` INT)
BEGIN
    UPDATE `Order_Detail` SET `Total`=`Quantity` *  `Unit_Price` * `Discount` WHERE `Order_Detail_ID` = `Old_OID`;
    UPDATE `Product` SET `Product_Quantity` = `Product_Quantity` + `Quantity` WHERE `Product_ID` = `Prod_ID`;
END;


CREATE PROCEDURE Failed_Order (IN `Old_OID` INT(10), IN `Quantity` INT, IN `Prod_ID` INT)
BEGIN
    DELETE FROM `Order_Detail` WHERE `Order_Detail_ID` = `Old_OID`;
    UPDATE `Product` SET `Product_Quantity` = `Product_Quantity` + `Quantity` WHERE `Product_ID` = `Prod_ID`;
END;

--
--
/* !40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/* !40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/* !40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
