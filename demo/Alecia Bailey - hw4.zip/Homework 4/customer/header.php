<!DOCTYPE html>
<html lang="en">
<head>
    <title>Customer - Inventory Management System</title>
    <meta charset="UTF-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
    <link rel="stylesheet" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" href="css/bootstrap-responsive.min.css"/>
    <link rel="stylesheet" href="css/fullcalendar.css"/>
    <link rel="stylesheet" href="css/matrix-style.css"/>
    <link rel="stylesheet" href="css/matrix-media.css"/>
    <link href="font-awesome/css/font-awesome.css" rel="stylesheet"/>
    <link rel="stylesheet" href="css/jquery.gritter.css"/>
    <link href='http://fonts.googleapis.com/css?family=Open+Sans:400,700,800' rel='stylesheet' type='text/css'>
</head>
<body>


<div id="header">

    <h3 style="color: white;position: absolute">
        <a href="#" style="color:white; margin-left: 30px; margin-top: 40px">USER PANEL</a>
    </h3>
</div>



<!--top-Header-menu-->
<!--<div id="user-nav" class="navbar navbar-inverse">-->
<!--    <ul class="nav">-->
<!--        <li class="dropdown" id="profile-messages">-->
<!--            <a title="" href="#" data-toggle="dropdown" data-target="#profile-messages" class="dropdown-toggle"><i-->
<!--                    class="icon icon-user"></i> <span class="text">Welcome</span><b class="caret"></b></a>-->
<!--        </li>-->
<!---->
<!---->
<!--    </ul>-->
<!--</div>-->

<!--sidebar-menu-->
<div id="sidebar">
    <ul>
        <li class="active">
            <a href="dashboard.php"><i class="icon icon-home"></i><span>Dashboard</span></a>
        </li>
        <li>
            <a href="order_product.php"><i class="icon icon-home"></i><span>Order Product</span></a>
        </li>
        <li>
            <a href="edit_order.php"><i class="icon icon-home"></i><span>Edit Order</span></a>
        </li>
        <li><a href="delete_order.php"><i class="icon icon-home"></i><span>Delete Order</span></a></li>
        <li>
            <a href="billing.php"><i class="icon icon-home"></i><span>Payment and Billing</span></a>
        </li>

    </ul>
</div>
