<?php
require "mongo.php";
session_start();
include "header.php";
?>

<div id="content">
<!--breadcrumbs-->
<div id="content-header">
    <div id="breadcrumb"><a href="#" class="tip-bottom"><i class="icon-home"></i>
            Payment and Billing</a></div>
</div>
<!--End-breadcrumbs-->
<!--Action boxes-->

    <div class="container-fluid">
        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
            <div class="span12">
                <div class="widget-box">
                    <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                        <h5>Payment</h5>
                    </div>
                    <div class="widget-content nopadding">
                        <form name="form1" action="" method="post" class="form-horizontal">

                            <div class="control-group">
                                <label class="control-label">Select Payment Type</label>

                                <div class="controls">
                                    <select class="span11" name="purchase_type">
                                        <option>Cash</option>
                                        <option>Debit</option>
                                        <option>Credit</option>
                                    </select>
                                </div>
                            </div>

                            <div class="control-group">
                                <label class="control-label">Other Details:</label>

                                <div class="controls">
                                    <input type="text" name="other" id="details" value="0" class="span11">
                                </div>
                            </div>

                            <div class="form-actions">
                                <button type="submit" name="submit1" class="btn btn-success">Pay Now </button>
                            </div>

                        </form>
                    </div>
                </div>

            </div>
        </div>

        <div class="container-fluid">

            <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
                <h4>Detailed Bills</h4>
                <table>
                    <tr>
                        <td>Bill No:</td>
                        <td><?php echo $bill_no; ?></td>
                    </tr>
                    <tr>
                        <td>Payment Type:</td>
                        <td><?php echo $payment_type; ?></td>
                    </tr>
                    <tr>
                        <td>Other_details:</td>
                        <td><?php echo $other_details; ?></td>
                    </tr>
                    <tr>
                        <td>Bill Date:</td>
                        <td><?php echo $today_date; ?></td>
                    </tr>
                </table>
                <br>


            </div>

        </div>
    </div>

<?php

    $id=$_GET["id"];
    $today_date=date('Y-m-d');
    $cursor = $db->$hw4->Payment;

    $cursor ->insertOne([
        "purchase_type"=>$_POST['payment_type'],
        "bill_no"=>$_POST['bill_number'],
        "other_details"=>$_POST['other_details']
    ]);

?>

<?php
include "footer.php";
?>