<?php
require "mongo.php";
session_start();
include "header.php";
?>

<div id="content">
    <!--breadcrumbs-->
    <div id="content-header">
        <div id="breadcrumb"><i class="icon-home"></i>
                Welcome To Dashboard</div>
    </div>
    <!--End-breadcrumbs-->

    <!--Action boxes-->
    <div class="container-fluid">

        <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">

            <div class="card" style="width: 18rem; border-style:solid; border-width: 1px; border-radius:10px; float:left">
                <div class="card-body">
                    <h3 class="card-title text-center">List of Products</h3>
                    <h1 class="card-text text-center">
                        <?php
                            $collection= $db->hw4->Product;
                            $cursor=$collection->find();
                            if($cursor){
                                $json=array();
                                foreach($cursor as $row){
                                    echo "<tr>";
                                        echo ("<td>" . $row['_id'] . "</td>");
                                        echo ("<td>" . $row['product_name'] . "</td>");
                                        echo ("<td>" . $row['product_description'] . "</td>");
                                        echo ("<td>" . $row['product_unit'] . "</td>");
                                        echo ("<td>" . $row['product_price'] . "</td>");
                                        echo ("<td>" . $row['product_quantity'] . "</td>");
                                        echo ("<td>" . $row['product_status'] . "</td>");
                                        echo ("<td>" . $row['other_details'] . "</td>");
                        ?>     
                                   </tr>
                        <?php            
                                }//end foreach

                            }//endif    
                        ?>
                    </h1>
                    <br><br>
                </div>
            </div>
        </div>
    </div>
</div>

<?php
include "footer.php";
?>