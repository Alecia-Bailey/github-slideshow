<?php
require "mongo.php";
include "header.php";

$id=$_GET["Order_Detail_ID"];
$unit="";
$qty="";
$discount="";

?>
    <div id="content">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="#" class="tip-bottom"><i class="icon-home"></i>
                    Edit Order</a></div>
        </div>
        <!--End-breadcrumbs-->
        <!--Action boxes-->
        <div class="container-fluid">
            <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
                <div class="span12">
                    <div class="widget-box">
                        <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                            <h5>Edit Order</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <form name="form1" action="" method="post" class="form-horizontal">
                                <div class="control-group">
                                    <label class="control-label">Select Order:</label>

                                    <div class="controls">
                                        <select class="span11" name="id">
                                            <?php
                                            $res=mysqli_query($link,"select * from Order_Detail");
                                            while($row=mysqli_fetch_array($res))
                                            {
                                            ?>
                                            <option <?php if($row["Order_Detail_ID"]==$id){echo "selected";} ?>>
                                                <?php
                                                echo $row["Order_Detail_ID"];
                                                echo "</option>";
                                            }
                                                ?>
                                        </select>

                                    </div>
                                </div>


                                <div class="control-group">
                                    <label class="control-label">Enter Unit Price:</label>

                                    <div class="controls">
                                        <input type="number" name="unit" class="span11" placeholder="Enter Price" value="<?php echo $unit; ?>">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Quantity:</label>

                                    <div class="controls">
                                        <input type="number" name="qty" class="span11" placeholder="Enter Quantity" value="<?php echo $qty; ?>">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Discount:</label>

                                    <div class="controls">
                                        <input type="number" name="discount" class="span11" placeholder="Enter Discount" value="<?php echo $discount; ?>">
                                    </div>
                                </div>

                                <div class="form-actions">
                                    <button type="submit" name="submit1" class="btn btn-success">Save</button>
                                </div>

                                <div class="alert alert-success" id="success" style="display:none">
                                    Record Updated Successfully!
                                </div>
                            </form>
                        </div>
                    </div>


                </div>
            </div>


        </div>


    </div>


<?php
if (isset($_POST["submit1"])) {
   if (array_key_exists('Order_detail._id', $_POST)){
        $id = $_POST['Product._id'];
        echo $_POST['Order_detail._id'];
        $price = $Product ->findOne(['_id' => new MongoDB\BSON\ObjectId($id)])['product_price'];
        $total = intval($_POST['quantity']) * intval($price);

        $Order_detail->updateOne(
            ['_id' => new MongoDB\BSON\ObjectId($_POST['Order_detail._id'])],
            ['$set' => [ 
                'unit_price' => $price,
                'customer_id' => $_POST['Customer._id'],
                'quantity' => $_POST['qty'],
                'discount' => $_POST['discount'],
                'total' => $total,
                'product_id' => $_POST['Product._id'],
                ]
            ]
        );
   }
}

?>

<?php
include "footer.php";
?>