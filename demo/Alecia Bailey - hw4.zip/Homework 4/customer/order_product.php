<?php
session_start();
require "mongo.php";
include "header.php";
?>
    <div id="content">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="#" class="tip-bottom"><i class="icon-home"></i>
                    Order Product</a></div>
        </div>
        <!--End-breadcrumbs-->
        <!--Action boxes-->
        <div class="container-fluid">
            <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
                <div class="span12">
                    <div class="widget-box">
                        <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                            <h5>Order Product</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <form name="form1" action="" method="post" class="form-horizontal">
                                <div class="control-group">
                                    <label class="control-label">Enter Price:</label>

                                    <div class="controls">
                                        <input type="number" name="price" value="0" class="span11">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Quantity</label>

                                    <div class="controls">
                                        <input type="number" name="qty" id="qty" value="0" class="span11" onkeyup="generate_total(this.value)">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Discount:</label>

                                    <div class="controls">
                                        <input type="number" name="discount" value="0" class="span11">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Product ID</label>

                                    <div class="controls">
                                        <input type="text" name="prod_id" value="0" class="span11">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Status</label>

                                    <div class="controls">
                                        <input type="text" name="status" value="0" class="span11">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Other Details</label>

                                    <div class="controls">
                                         <input type="text" name="other_details" value="0" class="span11">
                                    </div>
                                </div>

                                <div class="form-actions">
                                    <button type="submit" name="submit1" class="btn btn-success" onclick="window.location='billing.php';">Order Now </button>
                                </div>

                                <div class="alert alert-success" id="success" style="display:none">
                                    Product Ordered Successfully!
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>


        </div>


    </div>


    <script type="text/javascript">

        function generate_total(qty) {
            total = eval(price) * eval(qty) * eval(discount);
        }
    </script>

<?php
if (isset($_POST["submit1"])) {

    $today_date=date('Y-m-d');
    $total=eval(price)*eval(qty)*eval(discount);
    
    $cursor= $db->hw4->Order_detail;
    $cursor-> insertOne([
       "price" => $_POST['price'],
       "qty" => $_POST['qty'],
       "discount" => $_POST['discount'],
       "total" => $_POST['total'],
       "date" => $_POST['$today_date'],
       "prod_id" => $_POST['prod_id'],
       "status" => $_POST['status']
    ]);
    

    ?>
    <script type="text/javascript">
        document.getElementById("success").style.display="block";
        alert("Product Ordered Successfully!");
        window.location="order_product.php?id";
    </script>
    <?php


}
?>

<?php
include "footer.php";
?>