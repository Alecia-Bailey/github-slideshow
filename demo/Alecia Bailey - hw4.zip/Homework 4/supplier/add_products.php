<?php
require "mongo.php";
session_start();
include "header.php";
?>
    <div id="content">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="#" class="tip-bottom"><i class="icon-home"></i>
                    Add New Products</a></div>
        </div>
        <!--End-breadcrumbs-->
        <!--Action boxes-->
        <div class="container-fluid">
            <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
                <div class="span12">
                    <div class="widget-box">
                        <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                            <h5>Add New Products</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <form name="form1" action="" method="post" class="form-horizontal">
                                <div class="control-group">
                                    <label class="control-label">Enter Product Name:</label>

                                    <div class="controls">
                                       <input type="text" name="product_name" class="span11" placeholder="Enter Product Name">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Description:</label>

                                    <div class="controls">
                                        <div class="controls">
                                            <input type="text" name="product_desc" class="span11" placeholder="Description">
                                        </div>

                                    </div>
                                </div>


                                <div class="control-group">
                                    <label class="control-label">Enter Product Unit</label>

                                    <div class="controls">
                                        <input type="text" name="unit" class="span11" placeholder="Enter unit">
                                    </div>
                                </div>

<!--                                <div class="alert alert-danger" id="error" style="display:none">-->
<!--                                    This Products is Already Exist! Please Try Another.-->
<!--                                </div>-->

                                <div class="control-group">
                                    <label class="control-label">Enter Product Price</label>

                                    <div class="controls">
                                        <input type="number" name="price" class="span11" placeholder="Enter price">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Product Quantity</label>

                                    <div class="controls">
                                        <input type="number" name="qty" class="span11" placeholder="Enter quantity">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Product Status</label>

                                    <div class="controls">
                                        <input type="number" name="status" class="span11" placeholder="Enter status">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Other Details</label>

                                    <div class="controls">
                                        <input type="text" name="other_details" class="span11" placeholder="Enter other details">
                                    </div>
                                </div>


                                <div class="form-actions">
                                    <button type="submit" name="submit1" class="btn btn-success">Save</button>
                                </div>

                                <div class="alert alert-success" id="success" style="display:none">
                                    Record Inserted Successfully!
                                </div>
                            </form>
                        </div>
                    </div>
                    
                    <?php
                        $collection= $db->hw4->Product;
                        $cursor=$collection->find();
                        if($cursor){
                            $json=array();
                            foreach($cursor as $row){
                                echo "<tr>";
                                    echo ("<td>" . $row['_id'] . "</td>");
                                    echo ("<td>" . $row['product_name'] . "</td>");
                                    echo ("<td>" . $row['product_description'] . "</td>");
                                    echo ("<td>" . $row['product_unit'] . "</td>");
                                    echo ("<td>" . $row['product_price'] . "</td>");
                                    echo ("<td>" . $row['product_quantity'] . "</td>");
                                    echo ("<td>" . $row['product_status'] . "</td>");
                                    echo ("<td>" . $row['other_details'] . "</td>");
                    ?>
                                    <td>
                                        <a href="edit_products.php?id=<?php echo $row["_id"]; ?>" style="color:green">Edit</a> 
                                    </td>
                                    <td>
                                        <a href="delete_products.php?id=<?php echo $row["_id"]; ?>" style="color:red">Delete</a>
                                    </td>
                                </tr>
                    <?php
                            }
                        };
                    ?>
                      
                </div>
            </div>


        </div>


    </div>


<!-- <?php 
if (isset($_POST["submit1"])) {
    $count = 0;
    $res = mysqli_query($link, "select * from products where product_name='$_POST[product_name]' && product_description='$_POST[product_desc]' && unit='$_POST[unit]' && status='$_POST[status]'") or die(mysqli_error($link));
    $count = mysqli_num_rows($res);
    if ($count > 0) {
        ?>
        <script type="text/javascript">
            document.getElementById("success").style.display = "none";
            document.getElementById("error").style.display = "block";
        </script>
        <?php
    } else {
        mysqli_query($link, "insert into products values('$_POST[product_name]','$_POST[product_desc]','$_POST[unit]','$_POST[price]','$_POST[qty]','$_POST[status]','$_POST[other_details]')") or die(mysqli_error($link));
        ?>
        <script type="text/javascript">
            document.getElementById("error").style.display = "none";
            document.getElementById("success").style.display = "block";
            setTimeout(function () {
                window.location.href = window.location.href;
            }, 3000);
        </script>
        <?php
    }
}
 ?> -->

<?php
include "footer.php";
?>