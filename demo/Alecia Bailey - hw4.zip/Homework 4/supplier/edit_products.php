<?php
require "mongo.php";
include "header.php";
?>
    <div id="content">
        <!--breadcrumbs-->
        <div id="content-header">
            <div id="breadcrumb"><a href="#" class="tip-bottom"><i class="icon-home"></i>
                    Edit Products</a></div>
        </div>
        <!--End-breadcrumbs-->
        <!--Action boxes-->

        <div class="container-fluid">
            <div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
                <div class="span12">
                    <div class="widget-box">
                        <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                            <h5>Edit Products</h5>
                        </div>
                        <div class="widget-content nopadding">
                            <form name="form1" action="" method="post" class="form-horizontal">
                                <div class="control-group">
                                    <label class="control-label"> Product Name:</label>

                                    <div class="controls">
                                        <input type="text" name="product_name" class="span11" placeholder="Enter Product Name" value="<?php echo $product_name; ?>">
                                    </div>

                                    </div>
                                </div>


                                <div class="control-group">
                                    <label class="control-label">Enter Description:</label>

                                    <div class="controls">
                                        <input type="text" name="product_desc" class="span11" placeholder="Enter Product Description" value="<?php echo $product_desc; ?>">
                                    </div>
                                </div>

                                <div class="control-group">
                                    <label class="control-label">Enter Product Unit</label>

                                    <div class="controls">
                                        <input type="text" name="unit" class="span11" placeholder="Enter unit" value="<?php echo $unit; ?>">
                                    </div>
                                </div>


                                <div class="control-group">
                                    <label class="control-label">Enter Product Status</label>

                                    <div class="controls">
                                        <input type="text" name="status" class="span11" placeholder="Enter Status" value="<?php echo $status; ?>">
                                    </div>
                                </div>


<!--                                <div class="alert alert-danger" id="error" style="display:none">-->
<!--                                    This Products is Already Exist! Please Try Another.-->
<!--                                </div>-->


                                <div class="form-actions">
                                    <button type="submit" name="submit1" class="btn btn-success">Save</button>
                                </div>

                                <div class="alert alert-success" id="success" style="display:none">
                                    Record Updated Successfully!
                                </div>
                            </form>
                        </div>
                    </div>


                </div>
            </div>


        </div>


    </div>


<?php
$id=$_GET["id"];
$product_name="";
$product_desc="";
$unit="";
$status="";

if (isset($_POST["submit1"])) {
    if (array_key_exists('Product._id', $_POST)){
        $Product -> deleteOne(['_id'=> new MongoDB\BSON\ObjectId($_POST['Product._id'])]);
        $Product -> insertMany([
            [
                'product_name' => $_POST['product_name'],
                'product_description' => $_POST['product_desc'], 
                'unit' => $_POST['unit'],
                'status'=> $_POST['status']
            ]
        ]);

    } 

}
?>

<?php
include "footer.php";
?>