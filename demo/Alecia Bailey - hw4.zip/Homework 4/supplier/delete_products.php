<?php
require "mongo.php";
include "header.php";
?>
<div id="content">
    <!--breadcrumbs-->
    <div id="content-header">
        <div id="breadcrumb"><a href="#" class="tip-bottom"><i class="icon-home"></i>
                Delete Products</a></div>
</div>
    <!--End-breadcrumbs-->
    <!--Action boxes-->

<div class="container-fluid">
<div class="row-fluid" style="background-color: white; min-height: 1000px; padding:10px;">
    <div class="span12">
        <div class="widget-box">
            <div class="widget-title"><span class="icon"> <i class="icon-align-justify"></i> </span>
                <h5>Deleting Product</h5>
            </div>
            <div class="widget-content nopadding">
                <form name="form1" action="" method="post" class="form-horizontal">

                    <div class="control-group">
                        <label class="control-label">ID to be deleted:</label>

                        <div class="controls">
                            <input type="text" name="delete_id" id="delete_id" value="0" class="span11">
                        </div>
                    </div>
                    <div class="form-actions">
                        <button type="submit" name="submit1" class="btn btn-success">Delete</button>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>


<?php
    $_id=$_GET["id"];
    $collection = $db->hw4->Product;
    $collection ->insertOne(["product_id"=>$_POST['$_id']]);
?>


<script type="text/javascript">
    window.location="add_products.php";
</script>
